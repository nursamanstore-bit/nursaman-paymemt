const form = document.getElementById('payForm');
const invoiceCard = document.getElementById('invoiceCard');
const invoiceBox = document.getElementById('invoiceBox');
const copyBtn = document.getElementById('copyBtn');
const downloadBtn = document.getElementById('downloadBtn');
const waBtn = document.getElementById('waBtn');
const year = document.getElementById('year');
year.textContent = new Date().getFullYear();

function formatIDR(num){
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(num);
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const amount = Number(document.getElementById('amount').value);
  const notes = document.getElementById('notes').value.trim();

  if(!name || !amount || amount < 1000){
    alert('Isi nama dan nominal minimal 1.000');
    return;
  }

  const id = 'INV-' + Math.random().toString(36).slice(2,8).toUpperCase();
  const date = new Date().toLocaleString('id-ID');

  const text = [
    `Tagihan: ${id}`,
    `Tanggal: ${date}`,
    `Nama: ${name}`,
    `Nominal: ${formatIDR(amount)}`,
    notes ? `Catatan: ${notes}` : null,
    ``,
    `Metode bayar:`,
    `• Transfer Bank (BCA 1234567890 a.n. NURSAMAN)`, 
    `• E-Wallet (Dana/OVO/Gopay 08xx-xxxx-xxxx)`,
    `• QRIS (scan pada halaman)`,
  ].filter(Boolean).join('\n');

  invoiceBox.textContent = text;
  downloadBtn.href = URL.createObjectURL(new Blob([text], {type: 'text/plain'}));
  invoiceCard.classList.remove('hidden');
});

copyBtn?.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(invoiceBox.textContent);
    copyBtn.textContent = 'Disalin ✓';
    setTimeout(() => copyBtn.textContent = 'Salin Rincian', 2000);
  } catch (e) {
    alert('Gagal menyalin.');
  }
});

waBtn?.addEventListener('click', () => {
  const name = document.getElementById('name').value.trim();
  const amount = Number(document.getElementById('amount').value);
  const notes = document.getElementById('notes').value.trim();

  const msg = encodeURIComponent(`Halo Admin, saya ingin bayar.\nNama: ${name || '-'}\nNominal: ${amount ? formatIDR(amount) : '-'}\nCatatan: ${notes || '-'}`);
  // Ganti nomor WA admin di bawah (62xxxxxxxxxx)
  const phone = '62xxxxxxxxxx';
  window.open(`https://wa.me/${phone}?text=${msg}`, '_blank');
});
