# NURSAMAN Payment (Static)
Halaman pembayaran statis siap deploy di **Vercel** (gratis).

> ⚠️ Ini contoh sederhana: belum terhubung gateway pembayaran. Kamu bisa pakai halaman ini untuk:
> - Membuat tagihan manual (teks bisa disalin/diunduh)
> - Menampilkan info metode bayar (rekening, e-wallet, QRIS)
> - Tombol chat WhatsApp ke admin

## Cara Pakai
1. **Edit data kamu**
   - Buka `index.html` -> bagian *Metode Pembayaran*.
   - Buka `script.js` -> ganti nomor WA admin (`phone = '62xxxxxxxxxx'`).  
   - (Opsional) Upload QRIS kamu ke folder `public/` lalu tampilkan di `index.html`.

2. **Deploy ke Vercel (tanpa beli domain)**
   - Masuk ke https://vercel.com (buat akun jika belum).
   - Klik **Add New… → Project**.
   - Pilih **Import Git Repository** (disarankan) atau **Deploy** lalu **Drag & Drop** folder proyek ini.
     - Jika via Git: upload folder ini ke GitHub sebagai repository, lalu connect di Vercel.
     - Jika via Drag & Drop: seret folder zip/ekstrak berisi file ini ke Vercel.
   - Saat diminta *Framework Preset*, pilih **Other** (static).
   - Setelah deploy, domain gratis akan seperti: `nursaman-payment.vercel.app` (sesuai *Project Name*).
   - Ubah **Project Name** untuk mengubah subdomain vercel.app:
     - Settings → General → Project Name → ganti `nursaman-payment` → Save.

3. **Custom domain vercel.app (gratis)**
   - Kamu **tidak perlu beli domain**. Cukup ubah *Project Name* agar subdomain jadi yang kamu mau, misalnya:
     - `nursaman-pay.vercel.app`
     - `nursaman-id-pay.vercel.app`

4. **(Opsional) Integrasi Gateway (Midtrans/Xendit/Stripe)**
   - **Midtrans Snap** (Indonesia): Tambah script Snap dan buat transaksi dari server (Vercel Serverless).
   - **Xendit/Stripe**: Biasanya butuh endpoint server untuk membuat `checkout_session`/`invoice`.
   - Struktur umum di Vercel:
     ```
     /api/checkout.js  -> membuat transaksi (server)
     /index.html       -> tombol "Bayar" memanggil /api/checkout
     ```

## Edit Cepat
- Ubah teks rekening/e-wallet di `<section> Metode Pembayaran`.
- Ganti warna brand di `styles.css` (`--brand`).

## Lisensi
Bebas dipakai & modifikasi.
